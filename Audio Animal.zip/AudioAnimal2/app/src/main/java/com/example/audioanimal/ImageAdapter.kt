package com.example.audioanimal

import android.content.Context
import android.media.MediaPlayer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class ImageAdapter(private val context: Context) : RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {

    private val imagesOff = arrayOf(R.drawable.monkey_off, R.drawable.rabbit_off, R.drawable.dog_off)
    private val imagesOn = arrayOf(R.drawable.monkey_on, R.drawable.rabbit_on, R.drawable.dog_on)
    private val audios = arrayOf(R.raw.monkey_audio, R.raw.rabbit_audio, R.raw.dog_audio)

    private var currentIndex = 0
    private var isPlaying = false
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.image_item, parent, false)
        return ImageViewHolder(view)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        holder.bind(imagesOff[position % imagesOff.size], imagesOn[position % imagesOn.size], audios[position % audios.size])
    }

    override fun getItemCount(): Int = Int.MAX_VALUE // to allow infinite swiping

    inner class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imageView: ImageView = itemView.findViewById(R.id.imageView)

        fun bind(imageOff: Int, imageOn: Int, audio: Int) {
            imageView.setImageResource(imageOff)
            imageView.setOnClickListener {
                if (isPlaying) {
                    mediaPlayer?.stop()
                    mediaPlayer?.release()
                    mediaPlayer = null
                    imageView.setImageResource(imageOff)
                } else {
                    mediaPlayer = MediaPlayer.create(context, audio)
                    mediaPlayer?.start()
                    imageView.setImageResource(imageOn)
                }
                isPlaying = !isPlaying
            }
        }
    }
}
